package org.itacademy.javatesting.assertj;

public class MainClass {
}
