package org.itacademy.javatesting.assertj;

public class MainClassTest {
}
