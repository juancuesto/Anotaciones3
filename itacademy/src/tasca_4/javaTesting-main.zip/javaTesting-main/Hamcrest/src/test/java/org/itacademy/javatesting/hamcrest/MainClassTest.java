package org.itacademy.javatesting.hamcrest;

public class MainClassTest {
}
