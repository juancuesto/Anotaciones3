package org.itacademy.javatesting.junit;

public class MainClass {
}
